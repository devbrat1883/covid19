# Databricks notebook source
dbutils.fs.unmount('/mnt/cases_deaths')

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.fs.mount(
    source='wasbs://processed@covidreportingdl1883.blob.core.windows.net/ecdc/cases_deaths',
    mount_point='/mnt/cases_deaths',
    extra_configs={'fs.azure.account.key.covidreportingdl1883.blob.core.windows.net':'8ij7HSkz9kdnbyL3ayo6JDHSHdX/HNUvAKU0T3/+5cnxOTvQ+smCGbEGW891cqyQF5q74sO2LOph+AStTEIfRw=='}
)

# COMMAND ----------

display(dbutils.fs.ls('/mnt/cases_deaths'))

# COMMAND ----------

# File location and type
file_location = "/mnt/cases_deaths"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","


df = spark.read.format("csv").option("inferSchema", infer_schema).option("header", first_row_is_header).option("sep", delimiter).load(file_location)

display(df)

# COMMAND ----------

spark.conf.set("spark.databricks.delta.properties.defaults.columnMapping.mode","name")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table delta_table_processed_cases;

# COMMAND ----------

#create delta table
df.write.format("delta").option("overwriteSchema","True").saveAsTable("delta_table_processed_cases")

# COMMAND ----------

