# Databricks notebook source
dbutils.fs.unmount('/mnt/testing')

# COMMAND ----------

dbutils.fs.mount(
    source='wasbs://processed@covidreportingdl1883.blob.core.windows.net/ecdc/testing',
    mount_point='/mnt/testing',
    extra_configs={'fs.azure.account.key.covidreportingdl1883.blob.core.windows.net':'8ij7HSkz9kdnbyL3ayo6JDHSHdX/HNUvAKU0T3/+5cnxOTvQ+smCGbEGW891cqyQF5q74sO2LOph+AStTEIfRw=='}
)


# COMMAND ----------

display(dbutils.fs.ls('/mnt/testing'))

# COMMAND ----------

# File location and type
file_location = "/mnt/testing"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format("csv").option("inferSchema", infer_schema).option("header", first_row_is_header).option("sep", delimiter).load(file_location)

display(df)

# COMMAND ----------

spark.conf.set("spark.databricks.delta.properties.defaults.columnMapping.mode","name")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table delta_table_processed_testing;

# COMMAND ----------

#create delta table
df.write.format("delta").option("overwriteSchema","True").saveAsTable("delta_table_processed_testing")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta_table_processed_cases;

# COMMAND ----------

